
#create Enemies and Mario from Person
class person:

	#If typ is 1,it is Mario 
	#If type is 0,it is Enemy
	def __init__(self,x,y,lives,speed,score,typ,prev_val,flag):
		self.x=x
		self.y=y
		self.speed=speed
		if typ is 1:
			self.lives=lives
			self.score=score
			self.prev_val=' '
			self.flag=flag

	#left movement
	def moveLeft(self,X,typ):
		if typ is 1:
			x=self.x
			y=self.y
			if self.flag:
				X[x][y]=self.prev_val
			if y-self.speed>=0:
				if X[x][y-self.speed] not in ['T','S','B','|','_']:
					self.y=y-self.speed
					self.flag=1
					self.prev_val=X[self.x][self.y]
					if X[x][self.y] is 'O':
						self.score+=1
						self.prev_val=' '

				if X[self.x-self.speed][self.y] is 'E':
					self.lives=self.lives-1

		return X
				

	#right movement
	def moveRight(self,X,typ):
		if typ is 1:
			x=self.x
			y=self.y
			if self.flag:
				X[x][y]=self.prev_val
			if y+self.speed<=89:
				if X[x][y+self.speed] not in ['T','S','B','|','_']:
					self.y=y+self.speed
					self.flag=1
					self.prev_val=X[self.x][self.y]
					if X[x][self.y] is 'O':
						self.score+=1
						self.prev_val=' '			

	
				
		return X
		

	#bullet by mario
	def rightBullet(self,X):
		if X[self.x][self.y+1] is 'E' or X[self.x][self.y+1] is 'L':
			self.score+=1	
			self.lives+=1
		return X

	def leftBullet(self,X):
		if X[self.x][self.y-1] is 'E' or X[self.x][self.y-1] is 'L':
			self.score+=1
			self.lives+=1
		return X

	#mario jump
	def Jump(self,X,typ):
		if typ is 1:
			x=self.x
			y=self.y
			if self.flag:
				X[x][y]=self.prev_val
			b=1
			a=1
			l=0
			for i in range(1,11):
				if X[x-i][y] in ['S','B','T','|','_']:
					b=0
					l=i
					break
			
			if b is 0:
				if X[x-l][y] is 'S':
					self.lives+=1
				if X[x-l][y] is 'B':
					self.score+=1

			else:
				if X[x-10][y+1] not in ['S','B','T','|','_'] and (x-10)>=0:
					for i in range(1,11):
						if X[x-10+i][y+1] in ['S','B','T','|','_']:
							a=0
							l=i
							break
				if a is 0:
					self.x=x-11+l
					self.y=y+1
					self.flag=1

				else:
					self.flag=1
					self.y=y+1
		self.prev_val=X[self.x][self.y]
		X[self.x][self.y]='P'
		return X


