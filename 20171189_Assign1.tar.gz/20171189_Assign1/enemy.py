from player import *

#create enemy from person
class enemy(person):
	def __init__(self,x,y,lives,speed,score,typ,prev_val,flag):
		person.__init__(self,x,y,lives,speed,score,typ,prev_val,flag)

	def create(self,X):
		X[self.x][self.y]='E'
		return X

	def move(self,X,x,y):
		X[self.x][self.y]=' '
		if(self.y==y+4):
			self.y=y
		if (self.y<y+4) and (self.y>=y):
			self.y=self.y+1
		X[self.x][self.y]='E'
		return X

#create specialenemy from spEnemy
class spEnemy(enemy):
	def __init__(self,x,y,lives,speed,score,typ,prev_val,flag):
		enemy.__init__(self,x,y,lives,speed,score,typ,prev_val,flag)

	def create(self,X):
		X[self.x][self.y]='L'
		return X