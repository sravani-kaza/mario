import sys
import os
from colorama import init
from board import *
from player import *
from getch import _GetchUnix
from objects import *
from enemy import *
from random import randint

#input
getch = _GetchUnix()

#initiate colorama
init()

#create Board
A=Board(24,90)

#create mario
M=person(20,1,3,1,0,1,' ',1)
A.mat[M.x][M.y]='P'

#crete Flag and finish line
A.mat=(Finish().create(A.mat,8,88))
A.mat=(Flag().create(A.mat,10,80))

# create obstacles
Cl=[[2,55],[2,20]]
Bu=[[20,4]]
Bl=[[12,10],[12,11],[12,13],[12,14]]
spBl=[[12,12],[15,28],[15,70]]
Tu=[[17,20]]
C=[[14,28],[20,61],[20,62],[20,63],[20,64],[14,70],[7,70]]
E=[[20,65],[11,10],[20,14]]


A.mat=(steps().create(A.mat,20,35))

for i in Bu:
	A.mat=(bush().create(A.mat,i[0],i[1]))

for i in Bl:
	A.mat=(createBlock(Block(),A.mat,i[0],i[1]))

for i in spBl:
	A.mat=(createBlock(spBlock(),A.mat,i[0],i[1]))

for i in Tu:
	A.mat=(Tunnel().create(A.mat,i[0],i[1]))

for i in C:
	A.mat=(coins().create(A.mat,i[0],i[1]))

for i in Cl:
	A.mat=(cloud().create(A.mat,i[0],i[1]))


#create Enemies
E0=(enemy(20,65,0,2,0,2,0,0))
E1=(enemy(11,10,0,2,0,2,0,0))
E3=(enemy(20,14,0,2,0,2,0,0))
A.mat=(E0.create(A.mat))
A.mat=(E1.create(A.mat))
A.mat=(E3.create(A.mat))

#printBoard
def printBoard(A,M):
	print("\033[1;34;40m"+ "BASIC MARIO GAME: LEVEL 1",end="\n")
	print("SCORE:",end="  ")
	print(M.score,end="\n")
	print("LIVES:",end="  ")
	print(M.lives,end="\n")
	
	if (M.y<20):
		for i in range(A.rows):
			for j in range(30):
				print(A.mat[i][j],end="")
			print(end="\n")
			
	if (M.y>=20 and M.y <40):
		for i in range(A.rows):
			for j in range(20,50):
				print(A.mat[i][j],end="")
			print(end="\n")

	if (M.y >= 40 and M.y <60):
		for i in range(A.rows):
			for j in range(40,70):
				print(A.mat[i][j],end="")
			print(end="\n")
			
	if (M.y >=60 and M.y <90):
		for i in range(A.rows):
			for j in range(60,90):
				print(A.mat[i][j],end="")
			print(end="\n")

m=1

while True:
	try:

		#clear terminal
		os.system('clear')
		A.mat[M.x][M.y]='P'

		#move enemies
		A.mat=E0.move(A.mat,20,65)
		A.mat=E1.move(A.mat,11,10)
		A.mat=E3.move(A.mat,20,14)
		A.mat[11][12]='O'

		#print board
		printBoard(A,M)

		#get keyboard input
		input=getch()

		#perform functions based on input

		#quit game
		if input is 'q':
			os.system('clear')
			print("GAME EXIT")
			break

		#move mario to left
		if input is 'a':
			A.mat=M.moveLeft(A.mat,1)

		#move mario to right
		if input is 'd':
			A.mat=M.moveRight(A.mat,1)

		#kill enemy on left
		if input is 'k':
			A.mat=M.leftBullet(A.mat)

		#kill enemy on right
		if input is 'l':
			A.mat=M.rightBullet(A.mat)

		#mario jumps
		if input is 'j':
			A.mat=M.Jump(A.mat,1)

		#reached flag
		if M.y is 80:
			M.score+=40

		#level cleared
		if M.y is 88:
			os.system('clear')
			print("LEVEL CLEARED")
			break

		#mario gets killed if meets enemies
		if A.mat[M.x][M.y] is 'E':
			M.lives=M.lives-1

		#game ends if lives are 0
		if M.lives is 0:
			os.system('clear')
			print("NO LIVES LEFT")
			break

		#part of jump gravity effect
		m=M.x
		n=0
		f=0
		for i in range(1,20-m):
			if A.mat[m+i][M.y] in ['T','B','S','_','|','X'] :
				n=1
				f=m+i-1
				break
		A.mat[M.x][M.y]=' '
		if n is 1:
			M.x=f
		else:
			M.x=20

	except:
		print("SOME ERROR HAS OCCURED")

	

exit(0)
