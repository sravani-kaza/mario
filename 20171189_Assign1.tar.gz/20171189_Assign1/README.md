# STEPS TO RUN THE CODE:
	Go to the folder that contains 20171189_Assign1
	Switch into 20171189_Assign1
	'python3 gameplay.py' is to be executed on terminal

# NOTATIONS:
	M : MARIO
	B : BLOCK
	S : SPECIAL BLOCK
	O : COINS
	E : ENEMY

# CONTROLS OF THE MARIO:
	d : Moves Right by ONE Block (if possible)
	a : Moves Left by ONE Block (if possible)
	j : Jump with gravity effect (if possible)
	k : Left Enemy is Killed If present Within ONE Block
	l : Right Enemy is Killed If present Within ONE Block

#SCORE:
	Mario gets score if it kills Enemy,gets coin,reaches Finish Line or Hits Block B
	
	 ________________________________
     	|       ACTIONS	    |  POINTS    |
     	|___________________|____________|
	|                   |            |
     	|	Kills Enemy | 1		 |
     	|	Gets Coin   | 1		 |
     	|	Hits Block  | 1		 |
     	|	Reaches End | 40	 |
     	|___________________|____________|

# LIVES:
	Mario has 3 lives by default at the beginning
	If the Mario is Killed by Enemy, it looses a life
	If the Mario Kills Enemy using K or L,it gets ONE life
	If the Mario Hits Special Block S,it gets ONE life
	Whenever Mario dies ,it regenerates in the same place

# OBSTACLES WITH DIAGRAMS:
	
	/\/\	  :  Bush


	/\/\/\
	|    |    :  Cloud
	\/\/\/


	  TT
	  TT	  :  Obstacle(Tunnel like)
	  TT	
	  TT

	       _
	     _| 
	   _|     :  Steps
	 _|	
	|	


# FUNCTIONALITY OF JUMP:
	If 'j' is pressed, without any obstacle near it,only right movement of the mario occurs
	
# GRAVITY EFFECT
	Gravity effect is seen whenever the mario is in air

# Background changes whenever mario reaches one-third of the screen

# If 'q' is pressed, Game will be "QUIT"

# If Lives are 0,Game "ENDS"

# If Mario reaches end with Lives greater than 0,Level is cleared.

# INFORMATION ABOUT FILES:

	gameplay.py 	:	main execution part and printing
	board.py    	:	creation of board
	player.py   	:	creation of persons and their movements(mario and enemy)
	enemy.py    	:	different types of enemies and their movements
	objects.py  	:	obstacles
	getch.py    	:	input detection
	requirements.txt:	all packages used
	README.md       :	information about the game.




