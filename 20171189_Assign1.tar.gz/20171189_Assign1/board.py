#create Board
class Board:
	def __init__(self,m,n):
		self.rows=m
		self.columns=n
		self.mat=[[' 'for i in range(self.columns)]for j in range(self.rows)]
		self.mat[0]=['_'for j in range(self.columns)]
		self.mat[m-3]=['X'for j in range(self.columns)]
		self.mat[m-2]=['X'for j in range(self.columns)]
		self.mat[m-1]=['_'for j in range(self.columns)]