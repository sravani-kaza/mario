#create bush
class bush:
	def __init__(self):
		pass
	def create(self,X,x,y):
		X[x][y]='/'
		X[x][y+1]='\\'
		X[x][y+2]='/'
		X[x][y+3]='\\'
		return X

#create block
class Block:
	def __init__(self):
		self.sym='B'

#create special block
class spBlock:
	def __init__(self):
		self.sym='S'

#draw Block using polymorphism
def createBlock(it,X,x,y):
	X[x][y]=it.sym
	return X

#flag creation
class Flag:
	def __init__(self):
		pass

	def create(self,X,x,y):
		for i in range(2,21):
			X[i][y]='*'
		X[x][y]='F'
		X[x+1][y]='L'
		X[x+2][y]='A'
		X[x+3][y]='G'
		return X

#Finish line creation
class Finish:
	def __init__(self):
		pass

	def create(self,X,x,y):
		for i in range(2,21):
			X[i][y]='*'
		X[x][y]='F'
		X[x+1][y]='I'
		X[x+2][y]='N'
		X[x+3][y]='I'
		X[x+4][y]='S'
		X[x+5][y]='H'
		return X	

#Tunnel creation
class Tunnel:
	def __init__(self):
		pass
	def create(self,X,x,y):
		X[x][y]='T'
		X[x+1][y]='T'
		X[x+2][y]='T'
		X[x+3][y]='T'
		X[x][y+1]='T'
		X[x+1][y+1]='T'
		X[x+2][y+1]='T'
		X[x+3][y+1]='T'
		return X

#creates steps
class steps:
	def __init__(self):
		pass
	def create(self,X,x,y):
		for i in range(10):
			if i%2 is 0:
				X[x-i][y+i]='|'
		
			else:
				X[x-i][y+i]='_'

		X[x-9][y+10]='_'
		X[x-9][y+11]='_'
		X[x-9][y+12]='_'
			
		for i in range(10):
			if i%2 is 0:
				X[x-i][y+22-i]='|'
			else:
				X[x-i][y+22-i]='_'	

		return X

#coin creation
class coins:
	def __init__(self):
		pass
	def create(self,X,x,y):
		X[x][y]='O'
		return X

#cloud creation
class cloud:
	def __init__(self):
		pass
	def create(self,X,x,y):
		X[x][y]='/'
		X[x][y+1]='\\'
		X[x][y+2]='/'
		X[x][y+3]='\\'
		X[x][y+4]='/'
		X[x][y+5]='\\'
		X[x+1][y]='|'
		X[x+1][y+5]='|'
		X[x+2][y]='\\'
		X[x+2][y+1]='/'
		X[x+2][y+2]='\\'
		X[x+2][y+3]='/'
		X[x+2][y+4]='\\'
		X[x+2][y+5]='/'
		return X



